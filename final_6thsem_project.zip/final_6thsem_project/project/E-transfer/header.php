<!DOCTYPE html>
<html>
<head>
	<title>Employee Transfer System</title>
		
		<script src="public/js/jquery.js" type="text/javascript"></script>
		<script src="public/js/bootstrap.min.js" type="text/javascript"></script>
		<link rel="stylesheet" type="text/css" href="./public/bootstrap/bstrp/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="./public/bootstrap/bstrp/css/bootstrap-theme.min.css">
		<link rel="stylesheet" type="text/css" href="./public/css/style.css">	
</head> 	
<body style="font-family:serif; font-style: italic; ">
