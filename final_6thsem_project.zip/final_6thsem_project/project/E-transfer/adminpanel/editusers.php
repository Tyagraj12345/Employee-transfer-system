<?php 
	
	ini_set('display_errors', 1);
	error_reporting(E_ALL);

	require 'dbconn.php';	
 				
 	if (($_GET['type'])=='edit') {
 			
 			require 'header.php';
			require 'navigation.php';
 			
 			$uid = $_GET['uid'];
 			$name = $_GET['name'];
 			// $email =$_GET['email'];
 			$city  = $_GET['city'];
 			$branch = $_GET['branch'];
 			// $department = $_GET['department'];


 			$selBranch="SELECT * FROM users WHERE name = '$name'";
 			// print_r($sql);
 			$res=mysqli_query($con,$selBranch);
 			// print_r($res);
 			$row = mysqli_num_rows($res);
 			// print_r($row);
 			
 			if (isset($_POST['update'])) {
 			extract($_POST);
            
            $sql="UPDATE users SET firstname='$name', branch='$branch',city = '$city' WHERE uid='$uid'";
            print_r($sql);
            $result=mysqli_query($con, $sql);
            
            if (!$result) {
                echo "do nothing";
            }
            else
            {
                header('Location:listusers.php');
            }
        }
 	}

        else if(($_GET['type'])=='delete'){
			
			$name = $_GET['name'];
	
			$sql="DELETE FROM users WHERE `firstname` = '$name'";
			$result= mysqli_query($con, $sql);
			if (!$result) 
			{
				die('Could not enter data: ' . mysqli_error($con));
			}
		else
		{
			$msg="User Deleted Succssesfull";
			header('location:listusers.php?msg='.$msg);
		}
}
 ?>
 <div cenvelopeontainer>
<div class="container">
	<div class='col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4'>
		<div class='panel panel-primary margin-top-200'>
			<div class='panel-heading text-center'>
				Edit  User About Information
			</div>
			<input type="hidden" name="uid" value="<?php echo "$uid"; ?>">
			<div class='panel-body'>
				<form class="pure-form pure-form-aligned" action="#" method="post">
					<div class="form-group">
						<input type="name" name="name" class="form-control" id="name" placeholder="Enter user name" required="" value="<?php echo $name; ?>">
					</div>
					<div class="form-group">
 					<select name="branches" class="form-control">	
 						<?php 
 							$sql="SELECT * FROM branch";
 							$result=mysqli_query($con,$sql);
 							while ($row=mysqli_fetch_array($result)) {
 								echo "<option>".$row['name']."</option>";
 						}
 			 			?>
 							</select> 			
 					</div>
 					<div class="form-group">
 					<select name="department" class="form-control">	
 						<?php 
 							$sql="SELECT * FROM department";
 							$result=mysqli_query($con,$sql);
 							while ($row=mysqli_fetch_array($result)) {
 								echo "<option>".$row['name']."</option>";
 						}
 			 			?>
 							</select> 			
 					</div>
					<div class="form-group">
 						<!-- <label>select city:</label> -->
 							<select name="cities" class="form-control">	
 						<?php 
 							$sql="SELECT * FROM city";
 							$result=mysqli_query($con,$sql);
 							while ($row=mysqli_fetch_array($result)) {
 								echo "<option>".$row['name']."</option>";
 						}
 			 			?>
 							</select> 			
 					</div>
 					<div class="form-group">
 							<select name="type" class="form-control">
 							<option>HeadOfDepartment</option>
 							<option>Employee</option>		
 							</select> 			
 					</div>
 					<div class="form-group">
						<input class="btn btn-primary  btn-block" type="submit" value="update" name="update">
					</div>
				</form>	
			</div>
		</div>
	</div>
</div>
</div>
<?php 
	require '../footer.php';
 ?>