<?php 
  
  session_start();

	ini_set('display_errors',1);
	error_reporting(E_ALL);

	require 'header.php';
	require 'navigation.php';
	require 'dbconn.php';

	if (!($_SESSION['user'])) {
		header('Location:../index.php');
	}
	else{
  $sql="SELECT * FROM department";  
  $result = mysqli_query($con, $sql) or die(mysqli_error($con));
  $count = mysqli_num_rows($result);
    if (!$count>0){
     $fmsg = "No Data Found ";
      header('location:addnewdepartment.php?fmsg='.$fmsg);
      }
	}
 ?>
 <div class="container">
  <br><br><br><h2 class="text-primary">Available Departmentes</h2><br><br>
    <a href="addnewdepartment.php"><button type="button" class="btn btn-success">Add New department</button></a><br><br> 
</a>
 <h1 class="text-success text-center">
    <?php 
        if (isset($_GET['msg'])) {
          echo $msg= $_GET['msg'];    
        }
    ?>
</h1>
<table class="table table-striped" class="table">
  <thead>
    <tr class="warning">
      <th>id</th>
      <th>department</th>
      <th></th>
      <th>branch</th>
      <th></th>
      <th>city</th>
      <th>lastmodified</th>
      <th>perform action</th>
      <th>              </th>    
    </tr>
  <tbody>
    <?php 
    $i=1;
        while($row = mysqli_fetch_array($result))
        {
            $uid=$row['uid'];
            $name=$row['name'];
            $branch=$row['branch'];
            $city=$row['city'];
            echo " <tr class='success'> ";
            echo "<th scope='row' class='danger'>".$i."</th>";
            echo "<td>" . $row['name'] . "</td>";
            echo "<td>" . '<span class="glyphicon glyphicon-arrow-right">'."</span>"."</td>";
            echo "<td>" . $row['branch'] . "</td>"; 
            echo "<td>" . '<span class="glyphicon glyphicon-arrow-right">'."</span>"."</td>";
            echo "<td>" . $row['city'] . "</td>";
            echo "<td>" . date($row['crdate'],strtotime($row['timestamp']))."</td>";
            echo "<td><a href='editdepartment.php?uid=$uid&name=$name&city=$city&type=edit'><button type='button' class='btn btn-info'>Edit department</button></a></td>";
            echo "<td><a href='editdepartment.php?name=$name&type=delete'><button type='button' class='btn btn-danger'>Delete department</button></a></td>";
            echo "</tr>";
            $i++; 
        }
    ?>
  </tbody>
</table>
</div>	
</thead>
</table>
</div>
 <?php 
 require '../footer.php';
?>