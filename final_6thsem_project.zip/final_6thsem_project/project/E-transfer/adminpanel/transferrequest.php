<?php 
  
  session_start();

  ini_set('display_errors',1);
  error_reporting(E_ALL);

  require 'header.php';
  require 'navigation.php';
  require 'dbconn.php';

  if (!($_SESSION['user'])) {
    header('Location:../index.php');
  }
  else{
  $sql="SELECT * FROM transfer_request";  
  $result = mysqli_query($con, $sql) or die(mysqli_error($con));
  $count = mysqli_num_rows($result);
    if (!$count>0){
     $fmsg = "No Data Found ";
      header('location:addpost.php?fmsg='.$fmsg);
      }
  }
 ?>
 <div class="container">
  <br><br><br><h2 class="text-primary">Sended by user Transfer Request's</h2><br><br>
 <h1 class="text-success text-center">
    <?php 
        if (isset($_GET['msg'])) {
          echo $msg= $_GET['msg'];    
        }
    ?>
</h1>
<table class="table table-striped">
  <thead>
    <tr class="warning">
      <th>id</th>
      <th>name</th>
      <th> </th>
      <th>City</th>
      <th> </th>
      <th>Branch</th>
      <th> </th>
      <th>Department</th>
      <th>lastmodified</th>
      <th></th>
      <th><---perform action---></th>
      <th></th>
    </tr>
  <tbody>
    <?php 
    $i=1;
        while($row = mysqli_fetch_array($result))
        {
            $uid=$row['uid'];
            $name=$row['name'];
            $city=$row['city'];
            $branch=$row['branch'];
            $department=$row['department'];

            echo " <tr class='success'> ";
            echo "<th scope='row' class='danger'>".$i."</th>";
            echo "<td>" . $row['name'] . "</td>";
            echo "<td>" . '<span class="glyphicon glyphicon-arrow-right">'."</span>"."</td>";
            echo "<td>" . $row['city'] . "</td>";
            echo "<td>" . '<span class="glyphicon glyphicon-arrow-right">'."</span>"."</td>";
            echo "<td>" . $row['branch'] . "</td>";
            echo "<td>" . '<span class="glyphicon glyphicon-arrow-right">'."</span>"."</td>";
            echo "<td>" . $row['department'] . "</td>";
           echo "<td>" . date($row['crdate'],strtotime($row['timestamp']))."</td>";
            echo "<td><a href='editpost.php?uid=$uid&name=$name&city=$city&branch=$branch&department=$department&type=edit'><button type='button' class='btn btn-success'>Transfer</button></a></td>";
            echo "<td><a href='editpost.php?name=$name&type=delete'><button type='button' class='btn btn-info'>Panding Request</button></a></td>";
            echo "<td><a href='editpost.php?name=$name&type=delete'><button type='button' class='btn btn-danger'>Delete Request</button></a></td>";
            echo "</tr>";
            $i++; 
        }
    ?>
  </tbody>
</table>
</div>  
</thead>
</table>
</div>
 <?php 
 require '../footer.php';
?>