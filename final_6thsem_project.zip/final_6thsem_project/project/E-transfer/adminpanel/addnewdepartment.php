<?php 
	
	ini_set('display_errors', 1);
	error_reporting(E_ALL);
	
	require 'header.php';
	require 'navigation.php';
	require 'dbconn.php';
 	
 	if (isset($_POST['add'])) {
		
		$name=mysqli_real_escape_string($con,$_POST['name']);
		$city=mysqli_real_escape_string($con,$_POST['cities']);
		$branch=mysqli_real_escape_string($con,$_POST['branches']);
		
		$sql = "INSERT INTO department (name,city,branch) VALUES('$name','$city','$branch')";
		 print_r($sql);
		$result=mysqli_query($con,$sql);

		if ($result == true) {
			echo '<script type="text/javascript">window.location = "listdepartment.php"</script>';	
		}
		else{
			echo "!!!!Errors in Entering Data ";
		}
}
 ?>

<div class="container">
	<div class='col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4'>
		<div class='panel panel-primary margin-top-200'>
			<div class='panel-heading text-center text-success'>Add New Department
			</div>
			<div class='panel-body'>
				<form action="#" method="post">
 				<div class="form-group">
						<input type="name" name="name" class="form-control" id="name" placeholder="Enter Department Name" required="">
					</div>
					<div class="form-group">
 					<select name="branches" class="form-control">	
 						<?php 
 							$sql="SELECT * FROM branch";
 							$result=mysqli_query($con,$sql);
 							while ($row=mysqli_fetch_array($result)) {
 								echo "<option>".$row['name']."</option>";
 						}
 			 			?>
 							</select> 			
 					</div>
					<div class="form-group">
 						<!-- <label>select city:</label> -->
 							<select name="cities" class="form-control">	
 						<?php 
 							$sql="SELECT * FROM city";
 							$result=mysqli_query($con,$sql);
 							while ($row=mysqli_fetch_array($result)) {
 								echo "<option>".$row['name']."</option>";
 						}
 			 			?>
 							</select> 			
 					</div>
 					<div class="form-group">
						<input class="btn btn-primary  btn-block" type="submit" value="add" name="add" id="add" class="form-control">
				  </div>
 				</form>	
			</div>
		</div>
	</div>
</div> 
  <?php 
 	require '../footer.php';
  ?>