<?php 
	
	ini_set('display_errors', 1);
	error_reporting(E_ALL);

	require 'dbconn.php';	
 				
 	if (($_GET['type'])=='edit') {
 			
 			require 'header.php';
			require 'navigation.php';
 			
 			$uid = $_GET['uid'];
 			$name = $_GET['name'];
 			$pincode  = $_GET['pincode'];

 			$selCity="SELECT * FROM city WHERE name = '$name'";
 			// print_r($sql);
 			$res=mysqli_query($con,$selCity);
 			// print_r($result);
 			$row = mysqli_num_rows($res);
 			print_r($row);
 			
 			if (isset($_POST['update'])) {
 			extract($_POST);
            
            $sql="UPDATE city SET name='$name', pincode = '$pincode' WHERE uid='$uid'";
            print_r($sql);
            $result=mysqli_query($con, $sql);
            
            if (!$result) {
                echo "do nothing";
            }
            else
            {
                header('Location:listcity.php');
            }
        }
 	}

        else if(($_GET['type'])=='delete'){
			
			$name = $_GET['name'];
	
			$sql="DELETE FROM city WHERE `name` = '$name'";
			$result= mysqli_query($con, $sql);
			if (!$result) 
			{
				die('Could not enter data: ' . mysqli_error($connection));
			}
		else
		{
			$msg="City Deleted Succssesfull";
			header('location:listcity.php?msg='.$msg);
		}
}
 ?>
<div class="container">
	<div class='col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4'>
		<div class='panel panel-primary margin-top-200'>
			<div class='panel-heading text-center'>
				Enter  City About Information
			</div>
			<input type="hidden" name="uid" value="<?php echo "$uid"; ?>">
			<div class='panel-body'>
				<form class="pure-form pure-form-aligned" action="#" method="post">
					<div class="form-group">
						<input type="name" name="name" class="form-control" id="name" value="<?php echo "$name"; ?>" placeholder="Enter New name" required="">
					</div>
					<div class="form-group">
						<input type="pincode" name="pincode" class="form-control" id="pincode" placeholder="Enter  New city pincode" value="<?php  echo "$pincode";?>" required="">
					</div>
				 	</div>
					<div class="form-group">
						<input class="btn btn-primary  btn-block" type="submit" value="update" name="update" class="form-control">
					</div>
				</form>	
			</div>
		</div>
	</div>
</div>
?>
<?php 
	require '../footer.php';
 ?>