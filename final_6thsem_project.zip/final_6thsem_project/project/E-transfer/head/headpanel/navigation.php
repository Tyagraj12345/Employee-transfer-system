<?php 
  if (session_status()==PHP_SESSION_NONE) {
    session_start();
  }
  ob_start();
 ?>
<?php 
  require 'header.php';

?> 
<nav class="navbar navbar-inverse navbar-static-top navbar-fixed-top" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand">E-Transfer</a>
    </div>
    <div>
      <ul class="nav navbar-nav">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">City
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="addcity.php">Add New City</a></li>
            <li><a href="listcity.php">List of Cities</a></li>
            <!-- <li><a href="">Delete City</a></li> -->
            <!-- <li><a href="">Update City</a></li> -->
          </ul>
        </li>
        <ul class="nav navbar-nav">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Branch
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="addnewbranch.php">Add New Branch</a></li>
            <li><a href="listbranch.php">List of Branch</a></li>
            <!-- <li><a href="">Delete City</a></li> -->
            <!-- <li><a href="">Update City</a></li> -->
          </ul>
           </li>
          </ul>
           <ul class="nav navbar-nav">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Department
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="addnewdepartment.php">Add New Department</a></li>
            <li><a href="listdepartment.php">View Departmentes</a></li>
            <!-- <li><a href="">Delete City</a></li> -->
            <!-- <li><a href="">Update City</a></li> -->
          </ul>
           </li>
          </ul>
          <ul class="nav navbar-nav">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Users  
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="addusers.php">Create New HOD</a></li>
            <li><a href="addusers.php">Create new employee</a></li>
            <li><a href="listusers.php">View Users</a></li>
            <!-- <li><a href="">Delete City</a></li> -->
            <!-- <li><a href="">Update City</a></li> -->
          </ul>
           </li>
          </ul>
          <ul class="nav navbar-nav">
          <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Post  
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="addpost.php">Add New Post</a></li>
            <!-- <li><a href="adminpanel/addusers.php">Create New Employee</a></li> -->
            <li><a href="listpost.php">View posts</a></li>
            <!-- <li><a href="">Delete City</a></li> -->
            <!-- <li><a href="">Update City</a></li> -->
          </ul>
           </li>
          </ul>
          <ul class="nav navbar-nav">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Requests  
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="addusers.php">View New Requests</a></li>
            <li><a href="addusers.php">View JobPost's Requests</a></li>
            <li><a href="addusers.php">Panding</a></li>
            </ul>
           </li>
          </ul>
           <ul class="nav navbar-nav">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Compains  
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="addusers.php">View New Complains</a></li>
            <li><a href="addusers.php">View Old Complains</a></li>
            <li><a href="addusers.php">Response</a></li>
            <li><a href="addusers.php">Panding</a></li>
            </ul>
           </li>
          </ul>
          </div>
     <ul class="nav navbar-nav navbar-right">
      <?php
    if (isset($_SESSION['user'])) {
      $user=$_SESSION['user'];
      echo "<li><a href=><span class=''></span>".$user."</a></li>";
      echo "<li><a href='../editprofile.php'><span class='glyphicon glyphicon-user'></span> Editprofile</a></li>";
      echo "<li><a href='../logout.php'><span class='glyphicon glyphicon-log-out'></span> Logout</a></li>";
    }
    else{
      echo " 
               <li><a href='../index.php'><span class='glyphicon glyphicon-log-in'></span> Login</a></li>";
    }
  ?>  
    </ul>
    </nav>
<?php
  require '../footer.php';
 ?>