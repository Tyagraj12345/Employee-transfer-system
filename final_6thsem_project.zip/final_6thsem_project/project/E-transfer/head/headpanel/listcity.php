<?php 
	
	session_start();

	ini_set('display_errors',1);
	error_reporting(E_ALL);

	require 'header.php';
	require 'navigation.php';
	require 'dbconn.php';

	if (!($_SESSION['user'])) {
		header('Location:../index.php');
	}
	else{
  $sql="SELECT * FROM city";  
  $result = mysqli_query($con, $sql) or die(mysqli_error($con));
  $count = mysqli_num_rows($result);
    if (!$count>0){
     $fmsg = "No Data Found ";
      header('location:addcity.php?fmsg='.$fmsg);
      }
	}
 ?>
 <div class="container">
  <br><br><br><h2 class="text-primary">Available Cities</h2><br><br>
    <a href="addcity.php"><button type="button" class="btn btn-success">Add New City</button></a><br><br> 
</a>
 <h1 class="text-success text-center">
    <?php 
        if (isset($_GET['msg'])) {
          echo $msg= $_GET['msg'];    
        }
    ?>
</h1>
<table class="table table-striped">
  <thead>
    <tr class="warning">
      <th>id</th>
      <th>city</th>
      <th>pincode</th>
      <th>lastmodified</th>
      <th>perform action</th>
      <th></th>
    </tr>
  <tbody>
    <?php 
    $i=1;
        while($row = mysqli_fetch_array($result))
        {
            $uid=$row['uid'];
            $name=$row['name'];
            $pincode=$row['pincode'];   
            echo " <tr class='success'> ";
            echo "<th scope='row' class='danger'>".$i."</th>";
            echo "<td>" . $row['name'] . "</td>";
            echo "<td>" . $row['pincode'] . "</td>";
            echo "<td>" . date("d-m-Y H:i:s",strtotime($row['timestamp']))."</td>";
            echo "<td><a href='editcity.php?uid=$uid&name=$name&pincode=$pincode&type=edit'><button type='button' class='btn btn-info'>Edit city</button></a></td>";
            echo "<td><a href='editcity.php?name=$name&type=delete'><button type='button' class='btn btn-danger'>Delete city</button></a></td>";
            echo "</tr>";
            $i++; 
        }
    ?>
  </tbody>
</table>
</div>	
</thead>
</table>
</div>
 <?php 
 require '../footer.php';
?>