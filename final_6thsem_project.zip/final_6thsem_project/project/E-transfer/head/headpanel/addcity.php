<?php 
		
	ini_set('display_errors', 1);
	error_reporting(E_ALL);

	require 'header.php';
	require 'dbconn.php';
	require 'navigation.php';
	

	if (isset($_POST['submit'])) {
		
		$name=mysqli_real_escape_string($con,$_POST['name']);
		$pincode=mysqli_real_escape_string($con,$_POST['pincode']);

		$sql = "INSERT INTO city (name,pincode) VALUES('$name','$pincode')";
		$result=mysqli_query($con,$sql);
		
		if ($result == true) {
			echo '<script type="text/javascript">window.location = "listcity.php"</script>';} 
}

?>
<div class="container">
	<div class='col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4'>
		<div class='panel panel-primary margin-top-200'>
			<div class='panel-heading text-center'>
				Enter Your City About Information
			</div>
			<div class='panel-body'>
				<form action="" method="post">
					<div class="form-group">
						<input type="name" name="name" class="form-control" id="name" placeholder="Enter Your city name" required="">
					</div>
					<div class="form-group">
						<input type="pincode" name="pincode" class="form-control" id="pincode" placeholder="Enter your city pincode" required="">
					</div>
				 	</div>
					<div class="form-group">
						<input class="btn btn-primary  btn-block" type="submit" value="add" name="submit" id="submit" class="form-control">
				  </div>
				</form>	
			</div>
		</div>
	</div>
</div>
<?php 
	require '../footer.php';
 ?>