<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

require 'dbconn.php';
	
	if (isset($_POST['submit_login'])) {
		if (!empty($_POST['email'])) {
			$get_email = mysqli_real_escape_string($con,$_POST['email']);
			$userSelectQuery = "SELECT * FROM users WHERE email = '$get_email'";			
			if ($userResource=mysqli_query($con,$userSelectQuery)) {
			 	$count = mysqli_num_rows($userResource);
			 	if ($count>0) {
			 		while ($row = mysqli_fetch_array($userResource)) {
			 			$user = $row['firstname'];
				     	$_SESSION['user'] = $user;
			 		}
			 	}
			 	else{
			 		$wrongemail = "invalid email address";
			 	}
			}
	}
	if (!empty($_POST['password'])) {
			 		$get_password=mysqli_real_escape_string($con,$_POST['password']);
			 		$passwordSelectQuery = "SELECT * FROM users WHERE password = md5('$get_password')";
			 		print_r($passwordSelectQuery);
			 	if ($passwordResult=mysqli_query($con,$passwordSelectQuery)) {
			 		if (mysqli_num_rows($passwordResult)==1) {
			 			header('Location:dashboard.php');
			 		}
			 	else{
			 		$wrongpassword="invalid password";
			 }
		}
	}
}
require "header.php";
?>
<div cenvelopeontainer">
<div class='col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4'>
<div class='panel panel-primary margin-top-200'>
	<div class='panel-heading text-center'>
		Login in to Account
	</div>

<div class='panel-body'>
<form action="#" method="post">
					

<div class="form-group">
	<div class="input-group margin-bottom-10">
		<span class="input-group-addon">
			<i class="glyphicon glyphicon-envelope"></i>
		</span>
			<input type="email" name="email" class="form-control" id="email" placeholder="Enter E-mail" required="">
				<p class="bg-danger">
					<?php 
						if (isset($wrongemail)) {
							echo $wrongemail;
							}
					?>
				</p>
	</div>
</div>
					
<div class="form-group">
	<div class="input-group margin-bottom-10">
		<span class="input-group-addon">
			<i class="glyphicon glyphicon-lock "></i>
		</span>
			<input type="password" name="password" class="form-control" id="password" placeholder="Enter Password" required="">
				<p class="bg-danger">
						<?php 
							if (isset($wrongpassword)) {
								echo $wrongpassword;
							}
						 ?>
					</p>
	</div>
</div>

<div class="checkbox">
	<label><input type="checkbox">Remember me</label>
</div>
				  
<div>
	<button type="submit" class="btn btn-success btn-block" name="submit_login">Login</button>
</div>
				</form>	
			</div>
		</div>
	</div>
</div>
<?php
require "footer.php";
?>