<?php 
  session_start();
  ob_start();
 ?>
<?php
  require 'dbconn.php';
  require 'header.php';

  $sql="SELECT * FROM transfer_request";  
  $result = mysqli_query($con, $sql) or die(mysqli_error($con));
  $count = mysqli_num_rows($result);
?> 
<script type="text/javascript">
  function myFunction() {
    $.ajax({
      url: "view_notification.php",
      type: "POST",
      processData:false,
      success: function(data){
        $("#notification-count").remove();          
        $("#notification-latest").show();$("#notification-latest").html(data);
      },
      error: function(){}           
    });
   }
   
   $(document).ready(function() {
    $('body').click(function(e){
      if ( e.target.id != 'notification-icon'){
        $("#notification-latest").hide();
      }
    });
  });
</script>
<nav class="navbar navbar-inverse navbar-static-top navbar-fixed-top" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand">E-Transfer</a>
    </div>
    <div>
      <ul class="nav navbar-nav">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">City
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="adminpanel/addcity.php">Add New City</a></li>
            <li><a href="adminpanel/listcity.php">All Cities</a></li>
            <!-- <li><a href="">Delete City</a></li> -->
            <!-- <li><a href="">Update City</a></li> -->
          </ul>
        </li>
        <ul class="nav navbar-nav">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Branch
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="adminpanel/addnewbranch.php">Add New Branch</a></li>
            <li><a href="adminpanel/listbranch.php">All Branches</a></li>
            <!-- <li><a href="">Delete City</a></li> -->
            <!-- <li><a href="">Update City</a></li> -->
          </ul>
           </li>
          </ul>
           <ul class="nav navbar-nav">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Department
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="adminpanel/addnewdepartment.php">Add New Department</a></li>
            <li><a href="adminpanel/listdepartment.php">All Departmentes</a></li>
            <!-- <li><a href="">Delete City</a></li> -->
            <!-- <li><a href="">Update City</a></li> -->
          </ul>
           </li>
          </ul>
          <ul class="nav navbar-nav">
          <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Users  
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <!-- <li><a href="adminpanel/addusers.php">Create New HOD</a></li> -->
            <li><a href="adminpanel/addusers.php">Create New Employee</a></li>
            <li><a href="adminpanel/listusers.php">All users</a></li>
            <!-- <li><a href="">Delete City</a></li> -->
            <!-- <li><a href="">Update City</a></li> -->
          </ul>
           </li>
          </ul>
          <ul class="nav navbar-nav">
          <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Post  
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="adminpanel/addpost.php">Add New Post</a></li>
            <!-- <li><a href="adminpanel/addusers.php">Create New Employee</a></li> -->
            <li><a href="adminpanel/listpost.php">All Posts</a></li>
            <!-- <li><a href="">Delete City</a></li> -->
            <!-- <li><a href="">Update City</a></li> -->
          </ul>
           </li>
          </ul>
          <ul class="nav navbar-nav" onclick="myFunction()">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Requests  
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="adminpanel/transferrequest.php"><span id="notification-count"><?php if($count>0) { echo $count; } ?></span>New Request
            </a></li>
            <li><a href="adminpanel/viewjobpost.php">JobPost's Request</a></li>
            <li><a href="addusers.php">Panding</a></li>
            </ul>
           </li>
          </ul>
          <ul class="nav navbar-nav">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Transfer's  
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="adminpanel/transferrequest.php">Transfered</a></li>
            <li><a href="adminpanel/viewjobpost.php">Panded Transfer</a></li>
            <li><a href="addusers.php">Deleted Transfer</a></li>
            </ul>
           </li>
          </ul>
          <ul class="nav navbar-nav">
        <li class="dropdown">
          <a class="dropdown-toggle" data-toggle="dropdown" href="#">Compains  
          <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="addusers.php">New Complains</a></li>
            <li><a href="addusers.php">Old Complains</a></li>
            <li><a href="addusers.php">Response</a></li>
            <li><a href="addusers.php">Panding</a></li>
            </ul>
           </li>
          </ul>
         </div>
         <ul class="nav navbar-nav navbar-right">
      <?php
    if (isset($_SESSION['user'])) {
      $user=$_SESSION['user'];
      echo "<li><a href=><span class=''></span>".$user."</a></li>";
      echo "<li><a href='editprofile.php'><span class='glyphicon glyphicon-user'></span> Editprofile</a></li>";
      echo "<li><a href='logout.php'><span class='glyphicon glyphicon-log-out'></span> Logout</a></li>";
    }
    else{
      echo "<li><a href='index.php'><span class='glyphicon glyphicon-log-in'></span> Login</a></li>";
    }
  ?>  
    </ul>
    </nav>
<?php
  require 'footer.php';
 ?>