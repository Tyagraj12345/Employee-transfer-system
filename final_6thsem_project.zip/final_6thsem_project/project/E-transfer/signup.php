<?php

ini_set('display_errors', 1);

error_reporting(E_ALL);

require "header.php";

require 'dbconn.php';

if (isset($_POST['register'])) {
	
	$fname = mysqli_real_escape_string($con, $_POST['fname']);
	$lname = mysqli_real_escape_string($con, $_POST['lname']);
	$email = mysqli_real_escape_string($con, $_POST['email']);
	$phnnumber = mysqli_real_escape_string($con, $_POST['number']);
	$password = mysqli_real_escape_string($con,$_POST['password']);
	$cpassword=mysqli_real_escape_string($con,$_POST['password_repeat']);
	$cheakUsertquery = "SELECT * FROM users WHERE firstname = '$fname'";
	$cheakuser=mysqli_query($con,$cheakUsertquery);
	if (mysqli_num_rows($cheakuser) > 0) {
			
			$umsg = "!!!Sorry Your Username is already exits<br>";
		}

	$cheakEmailQuery = "SELECT * FROM users WHERE email = '$email'";
	$cheakemail=mysqli_query($con,$cheakEmailQuery);
	if (mysqli_num_rows($cheakemail) > 0) {
			
			$emailmsg = "!!!!Sorry Your E-mail Address is already exits<br>";
		}	
	
	if ($password != $cpassword) {
			$checkpass ="!!!password is does not match";
		}
		else
		{
			$sqlQuery = "INSERT INTO users (firstname,lastname,email,phoneno,password) VALUES('$fname','$lname','$email','$phnnumber',md5('$password'))";
			print_r($sqlQuery);
			$insertresult=mysqli_query($con, $sqlQuery);
			print_r($insertresult);
			if ($insertresult==true) {
					
					header('Location:index.php');
			}
		}	
}
?>
<div class="container-fluid">
	<div class='col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4	'>
		<div class='panel panel-primary margin-top-200'>
			<div class='panel-heading text-center'>
				Sign up
			</div>
			<div class='panel-body'>
				<form action="" method="post">
					<div class="form-group">	
						<input type="text" name="fname" class="form-control" id="fname" placeholder="Enter FirstName" required="">
					</div>
					<div class="form-group">
						<input type="text" name="lname" class="form-control" id="lname" placeholder="Enter LastName" required="">
						<p class="bg-danger">
						<?php 
							if (isset($umsg)) {
								echo $umsg;
							}
						 ?>
						 </p>
					</div>
					<div class="form-group">
						<input type="email" name="email" class="form-control" id="email" placeholder="Enter E-mail" required="">
						<p class="bg-danger">
						<?php 
							if (isset($emailmsg)) {
								echo $emailmsg;
							}
						 ?>
						 </p>
					</div>
					<div class="form-group">
						<input type="text" name="number" class="form-control" id="number" placeholder="Enter Phonenumber" required="">
						<p class="bg-danger">
						<?php 
							if (isset($phnmsg)) {
								echo $phnmsg;
							}
						 ?>
						 </p>
					</div>
					<div class="form-group">
						<input type="password" name="password" class="form-control" id="password" placeholder="Enter Password" required="">
					</div>
					 <div class="form-group">
						<input type="password" name="password_repeat" class="form-control" id="password_repeat" placeholder="Conform Password" required="">
						<p class="bg-danger">
						<?php 
						if (isset($checkpass)) {
							echo $checkpass;
						}
						?>
						</p>	
					</div>
					<div class="form-group">
					<button type="submit" name="register" id="register" class="btn btn-primary" style="width: 100%;">signup</button>
				  </div>
				</form>	
			</div>
		</div>
	</div>
</div>
<?php
require "footer.php";
?>



