<?php
require "navigation.php";
?>
<br>
<br>

<br><br><br><br><br><br><br><br><br><br><br><br>
	<div class="text-center text-bold">
	<br>
	<p class="success">WelCome To Dashbord</p>
	<br>
	<?php 
		if (isset($user)) {
			echo "$user";
		}
	 ?>
	 <br>
	<br>
	Hurrrrrry!!!!!!!!!!!!!!!!
	<br>
	</div>

<?php

require "footer.php";

?>
