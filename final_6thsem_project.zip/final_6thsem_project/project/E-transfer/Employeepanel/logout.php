<?php

session_start();
unset($user);
session_destroy();
header('Location:index.php');
?>