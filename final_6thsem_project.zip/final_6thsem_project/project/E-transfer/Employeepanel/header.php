<?php 
  if (session_status()==PHP_SESSION_NONE) {
    session_start();
  }
  ob_start();
 ?>
 <?php 
      require 'links.php';
  ?>
<body style="font-family:serif; font-style: italic; ">
<style type="text/css">
    body{
        background-image: url(../../public/img/rf.jpg);
        background-position: center;
        background-attachment: fixed;
        background-size: 100%;
    }
</style>
<nav class="navbar navbar-inverse navbar-fixed-top">
<div class="container-fluid">
<div class="navbar-header">
	<a class="navbar-brand" href="">E-transfer</a>
</div>
	<ul class="nav navbar-nav">
			<li class="active"><a href="">Transfer Guideline</a></li>
			<li><a href="viewjobpost.php">View Available Post's</a></li>
			<li><a href="sendtrnsreq.php">Send Transfer Request</a></li>
      <li><a href="">Notification</a></li>
      <li><a href="">Complain</a></li>
	</ul>

 <ul class="nav navbar-nav navbar-right">
      <?php
    if (isset($_SESSION['user'])) {
      $user=$_SESSION['user'];
      echo "<li><a href=><span class=''></span>".$user."</a></li>";
      echo "<li><a href='../editprofile.php'><span class='glyphicon glyphicon-user'></span> Editprofile</a></li>";
      echo "<li><a href='logout.php'><span class='glyphicon glyphicon-log-out'></span> Logout</a></li>";
    }
    else{
      echo " 
               <li><a href='index.php'><span class='glyphicon glyphicon-log-in'></span> Login</a></li>";
    }
  ?>  
    </ul>
</div>
</nav>
<?php 
	require 'footer.php';
 ?>