<?php 
	ini_set('display_errors', 1);
	error_reporting(E_ALL);
	
	require 'header.php';
	require 'links.php';
	require 'dbconn.php';
 	
 	if (isset($_POST['create'])) {
		
		$name=mysqli_real_escape_string($con,$_POST['name']);
		$city=mysqli_real_escape_string($con,$_POST['cities']);
		$branch=mysqli_real_escape_string($con,$_POST['branches']);
		$department=mysqli_real_escape_string($con,$_POST['department']);
		
		$sql = "INSERT INTO transfer_request(name,city,branch,department) VALUES('$name','$city','$branch','$department')";
		print_r($sql);
		$result=mysqli_query($con,$sql);

		if ($result == true) {
			echo $requestSended = "Request Sended SuccessFully";
		}
		else{
			echo "!!!!Errors in Entering Data ";
		}
}
 ?>
 <script type="text/javascript">
 	function myFunction() {
		$.ajax({
			url: "../navigation.php",
			type: "POST",
			processData:false,
			success: function(data){
				$("#notification-count").remove();					
				$("#notification-latest").show();$("#notification-latest").html(data);
			},
			error: function(){}           
		});
	 }
	 
	 $(document).ready(function() {
		$('body').click(function(e){
			if ( e.target.id != 'notification-icon'){
				$("#notification-latest").hide();
			}
		});
	});
	</script>
<div class="container">
	<div class='col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4'>
		<div class='panel panel-primary margin-top-200'>
			<div class='panel-heading text-center text-success'>Send Transfer Request
			</div>
			<div class='panel-body'>
				<form action="#" method="post">
 				
					<div class="form-group">
						<input type="text" name="name" class="form-control" placeholder="Enter username" required="">
						</div>
					<div class="form-group">
 					<select name="branches" class="form-control">	
 						<?php 
 							$sql="SELECT * FROM branch";
 							$result=mysqli_query($con,$sql);
 							while ($row=mysqli_fetch_array($result)) {
 								echo "<option>".$row['name']."</option>";
 						}
 			 			?>
 							</select> 			
 					</div>
 					<div class="form-group">
 					<select name="department" class="form-control">	
 						<?php 
 							$sql="SELECT * FROM department";
 							$result=mysqli_query($con,$sql);
 							while ($row=mysqli_fetch_array($result)) {
 								echo "<option>".$row['name']."</option>";
 						}
 			 			?>
 							</select> 			
 					</div>
					<div class="form-group">
 						<!-- <label>select city:</label> -->
 							<select name="cities" class="form-control">	
 						<?php 
 							$sql="SELECT * FROM city";
 							$result=mysqli_query($con,$sql);
 							while ($row=mysqli_fetch_array($result)) {
 								echo "<option>".$row['name']."</option>";
 						}
 			 			?>
 							</select> 			
 					</div>
 					<div class="form-group">
						<input class="btn btn-primary  btn-block" type="submit" value="Send" name="create" id="add" class="form-control">
				  </div>
 				</form>	
			</div>
		</div>
	</div>
</div> 
  <?php 
 	require '../footer.php';
  ?>