<?php

session_start();
unset($user);
session_destroy();
// ob_end_flush();
header('Location:index.php');
?>