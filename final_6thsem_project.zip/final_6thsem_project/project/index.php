<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

require 'E-transfer/dbconn.php';
	
	if (isset($_POST['submit_login'])) {
		
			if ($_POST['type']=='Admin') {
					header('Location:E-transfer/');
			}
			if ($_POST['type']=='Head of Department'){
					header('Location:E-transfer/head/');
			}	
			if ($_POST['type']=='Employee'){
				header('Location:E-transfer/Employeepanel/');
			}
}

require "header.php";
?>
<div cenvelopeontainer">
<div class='col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4'>
<div class='panel panel-primary margin-top-200'>
	<div class='panel-heading text-center'>
		Select Your Type to Login
	</div>

<div class='panel-body'>
<form action="#" method="post">
					
<div class="form-group">
		<select name="type" class="form-control">
			<option>Admin</option>
			<option>Head of Department</option>
			<option>Employee</option>
		</select>
</div>

<div class="checkbox">
	<label><input type="checkbox">Remember me</label>
</div>
				  
<div>
	<button type="submit" class="btn btn-success btn-block" name="submit_login">Select</button>
</div>
				</form>	
			</div>
		</div>
	</div>
</div>
<?php
require "E-transfer/footer.php";
?>