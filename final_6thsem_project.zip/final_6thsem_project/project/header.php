<!DOCTYPE html>
<html>
<head>
	<title>Employee Transfer System</title>
		
		<script src="public/js/jquery.js" type="text/javascript"></script>
		<script src="public/js/bootstrap.min.js" type="text/javascript"></script>
		<link rel="stylesheet" type="text/css" href="public/bootstrap/bstrp/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="public/bootstrap/bstrp/css/bootstrap-theme.min.css">
		<link rel="stylesheet" type="text/css" href="public/css/style.css">	
</head> 	
<body style="font-family:serif; font-style: italic; ">
<style type="text/css">
		body{
				background-image: url(public/img/how_to_use_social_media_to_attract_and_hire_the_best_job_candidates.jpg);
				background-position: center;
				background-attachment: fixed;
				background-size: 100%;

		}
</style>