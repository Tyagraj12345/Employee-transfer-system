-- phpMyAdmin SQL Dump
-- version 4.6.4deb1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 21, 2017 at 02:03 PM
-- Server version: 5.7.18-0ubuntu0.16.10.1
-- PHP Version: 7.0.15-0ubuntu0.16.10.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emptransfer`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `uid` int(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`uid`, `username`, `email`, `password`) VALUES
(1, 'Admin', 'admin@gmail.com', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `application_request`
--

CREATE TABLE `application_request` (
  `uid` int(11) NOT NULL,
  `date` int(11) DEFAULT NULL,
  `employee` int(11) NOT NULL,
  `requrement` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `appliedpost`
--

CREATE TABLE `appliedpost` (
  `uid` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `branch` varchar(45) NOT NULL,
  `department` varchar(45) NOT NULL,
  `timestamp` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP
) ;

--
-- Dumping data for table `appliedpost`
--

INSERT INTO `appliedpost` (`uid`, `name`, `city`, `branch`, `department`, `timestamp`, `crdate`) VALUES
(1, 'XYZ', 'bhavnagar', 'IT', 'genral', '2017-05-18 08:36:00.759403', '2017-05-18 14:06:00'),
(2, 'aaa', 'bhavnagar', 'IT', 'genral', '2017-05-18 08:38:25.489635', '2017-05-18 14:08:25'),
(3, 'qqq', 'bhavnagar', 'IT', 'genral', '2017-05-18 08:39:02.626632', '2017-05-18 14:09:02'),
(4, 'rr', 'bhavnagar', 'IT', 'genral', '2017-05-18 08:41:16.358094', '2017-05-18 14:11:16');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `uid` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `crdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`uid`, `name`, `city`, `crdate`, `timestamp`) VALUES
(16, 'IT', 'ahamdabad', '2017-05-13 23:32:06', '2017-05-13 18:02:06'),
(17, 'mechanical', 'ahamdabad', '2017-05-13 23:32:30', '2017-05-13 18:02:30'),
(18, 'fabrication', 'rajkot', '2017-05-13 23:32:37', '2017-05-13 18:02:37'),
(19, 'computer', 'bhuj', '2017-05-13 23:32:47', '2017-05-13 18:02:47'),
(20, 'texttile', 'baroda', '2017-05-13 23:32:57', '2017-05-13 18:02:57'),
(21, 'machinary', 'baroda', '2017-05-13 23:33:19', '2017-05-13 18:03:19');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `uid` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `pincode` int(10) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`uid`, `name`, `pincode`, `timestamp`) VALUES
(29, 'bhavnagar', 364002, '2017-05-13 18:00:14'),
(30, 'ahamdabad', 365002, '2017-05-13 18:00:32'),
(31, 'baroda', 366002, '2017-05-13 18:00:50'),
(32, 'rajkot', 365550, '2017-05-13 18:01:05'),
(33, 'bhuj', 552240, '2017-05-13 18:01:46'),
(34, 'vadodara', 746464, '2017-05-27 14:19:46'),
(35, 'tokiyo', 7897, '2017-05-27 14:21:17'),
(36, 'bhava', 45, '2017-05-27 14:22:13'),
(37, 'bhava', 45, '2017-05-27 14:25:03'),
(38, 'asa', 66464, '2017-05-27 14:33:54');

-- --------------------------------------------------------

--
-- Table structure for table `complain`
--

CREATE TABLE `complain` (
  `uid` int(11) NOT NULL,
  `title` varchar(45) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `time` varchar(45) DEFAULT NULL,
  `employee` int(11) NOT NULL,
  `department` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `uid` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `branch` varchar(45) NOT NULL,
  `crdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`uid`, `name`, `city`, `branch`, `crdate`, `timestamp`) VALUES
(23, 'genral', 'bhavnagar', 'fabrication', '2017-05-13 23:33:41', '2017-05-13 18:03:41'),
(24, 'applied', 'ahamdabad', 'mechanical', '2017-05-13 23:33:54', '2017-05-13 18:03:54'),
(25, 'chemstry', 'baroda', 'mechanical', '2017-05-13 23:34:13', '2017-05-13 18:04:13'),
(26, 'physics', 'bhavnagar', 'texttile', '2017-05-13 23:34:27', '2017-05-13 18:04:27');

-- --------------------------------------------------------

--
-- Table structure for table `interview`
--

CREATE TABLE `interview` (
  `uid` int(11) NOT NULL,
  `date` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `application_request_uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `uid` int(11) NOT NULL,
  `name` varchar(45) NOT NULL DEFAULT '',
  `city` varchar(45) NOT NULL DEFAULT '',
  `branch` varchar(45) NOT NULL DEFAULT '',
  `department` varchar(45) NOT NULL DEFAULT '',
  `desciption` varchar(100) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `crdate` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`uid`, `name`, `city`, `branch`, `department`, `desciption`, `timestamp`, `crdate`) VALUES
(13, 'Branchmanager', 'bhavnagar', 'IT', 'genral', '', '2017-05-13 18:21:23', '2017-05-13 23:44:00'),
(14, 'departmentmanager', 'baroda', 'fabrication', 'applied', '', '2017-05-13 18:14:16', '2017-05-13 23:44:16'),
(15, 'departmentmeagement', 'rajkot', 'mechanical', 'chemstry', '', '2017-05-14 04:59:26', '2017-05-14 10:29:26');

-- --------------------------------------------------------

--
-- Table structure for table `requrement`
--

CREATE TABLE `requrement` (
  `uid` int(11) NOT NULL,
  `jobtitle` varchar(45) DEFAULT NULL,
  `job_description` varchar(45) DEFAULT NULL,
  `no_of_employee` varchar(45) DEFAULT NULL,
  `start_date` int(11) DEFAULT NULL,
  `end_date` int(11) DEFAULT NULL,
  `city` int(11) NOT NULL,
  `department` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transfer`
--

CREATE TABLE `transfer` (
  `uid` int(11) NOT NULL,
  `old_post` varchar(45) DEFAULT NULL,
  `old_city` varchar(45) DEFAULT NULL,
  `new_post` varchar(45) DEFAULT NULL,
  `new_city` varchar(45) DEFAULT NULL,
  `employee` int(11) NOT NULL,
  `interview` int(11) NOT NULL,
  `department` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transfer_request`
--

CREATE TABLE `transfer_request` (
  `uid` int(1) NOT NULL,
  `name` varchar(45) NOT NULL,
  `branch` varchar(45) NOT NULL,
  `department` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `crdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transfer_request`
--

INSERT INTO `transfer_request` (`uid`, `name`, `branch`, `department`, `city`, `timestamp`, `crdate`) VALUES
(1, 'ss', 'IT', 'genral', 'bhavnagar', '2017-05-27 14:49:54', '2017-05-27 20:19:54'),
(2, 'ss', 'IT', 'genral', 'bhavnagar', '2017-05-27 14:51:21', '2017-05-27 20:21:21'),
(3, 'ss', 'IT', 'genral', 'bhavnagar', '2017-05-27 14:51:39', '2017-05-27 20:21:39'),
(4, 'ss', 'IT', 'genral', 'bhavnagar', '2017-05-27 14:52:17', '2017-05-27 20:22:17'),
(5, 'ss', 'IT', 'genral', 'bhavnagar', '2017-05-27 14:52:36', '2017-05-27 20:22:36'),
(6, 'ss', 'IT', 'genral', 'bhavnagar', '2017-05-27 14:52:52', '2017-05-27 20:22:52'),
(7, 'ss', 'IT', 'genral', 'bhavnagar', '2017-05-27 14:53:51', '2017-05-27 20:23:51'),
(8, 'ss', 'IT', 'genral', 'bhavnagar', '2017-05-27 14:54:47', '2017-05-27 20:24:47'),
(9, 'ss', 'IT', 'genral', 'bhavnagar', '2017-05-27 14:54:56', '2017-05-27 20:24:56'),
(10, 'ss', 'IT', 'genral', 'bhavnagar', '2017-05-27 14:55:06', '2017-05-27 20:25:06'),
(11, 'ss', 'IT', 'genral', 'bhavnagar', '2017-05-27 14:55:27', '2017-05-27 20:25:27'),
(12, 'ss', 'IT', 'genral', 'bhavnagar', '2017-05-27 14:55:47', '2017-05-27 20:25:47'),
(13, 'ss', 'IT', 'genral', 'bhavnagar', '2017-05-27 14:56:52', '2017-05-27 20:26:52'),
(14, 'test', 'computer', 'chemstry', 'baroda', '2017-05-27 16:59:21', '2017-05-27 22:29:21');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `admin` int(11) DEFAULT NULL,
  `dept_head` int(11) DEFAULT NULL,
  `employee` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`admin`, `dept_head`, `employee`) VALUES
(0, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `firstname` varchar(45) DEFAULT NULL,
  `lastname` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `post` varchar(45) DEFAULT NULL,
  `department` varchar(45) DEFAULT NULL,
  `branch` char(45) NOT NULL,
  `current_salary` varchar(45) DEFAULT NULL,
  `phoneno` bigint(10) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `crdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `firstname`, `lastname`, `email`, `post`, `department`, `branch`, `current_salary`, `phoneno`, `password`, `type`, `city`, `address`, `crdate`, `timestamp`) VALUES
(132, 'Tyagraj_bhatt', NULL, 'Tyagrajbhatt457645@gmail.com', NULL, 'genral', 'IT', NULL, NULL, '9082a25040711ae1e26404578cad16fd', 'Employee', 'bhavnagar', NULL, '2017-05-15 10:43:13', '2017-05-15 05:13:13'),
(133, 'Pallav_shah', NULL, 'Pallavshah@gmail.com', NULL, 'genral', 'IT', NULL, NULL, 'ef794a7c2d8c68f21c36c4bb2108cedb', 'HeadOfDepartment', 'bhavnagar', NULL, '2017-05-15 10:45:18', '2017-05-15 05:15:18'),
(138, 'head', NULL, 'head@gmail.com', NULL, NULL, '', NULL, NULL, '7d2c2b2d6d291deda867806e5e278e78', NULL, NULL, NULL, '2017-05-15 12:11:08', '2017-05-15 06:41:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `application_request`
--
ALTER TABLE `application_request`
  ADD PRIMARY KEY (`uid`),
  ADD KEY `fk_application_request_users_idx` (`employee`),
  ADD KEY `fk_application_request_requrement1_idx` (`requrement`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `complain`
--
ALTER TABLE `complain`
  ADD PRIMARY KEY (`uid`),
  ADD KEY `fk_complain_users1_idx` (`employee`),
  ADD KEY `fk_complain_users2_idx` (`department`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `interview`
--
ALTER TABLE `interview`
  ADD PRIMARY KEY (`uid`),
  ADD KEY `fk_interview_application_request1_idx` (`application_request_uid`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `requrement`
--
ALTER TABLE `requrement`
  ADD PRIMARY KEY (`uid`,`city`),
  ADD KEY `fk_requrement_city1_idx` (`city`),
  ADD KEY `fk_requrement_users1_idx` (`department`);

--
-- Indexes for table `transfer`
--
ALTER TABLE `transfer`
  ADD PRIMARY KEY (`uid`),
  ADD KEY `fk_transfer_users1_idx` (`employee`),
  ADD KEY `fk_transfer_interview1_idx` (`interview`),
  ADD KEY `fk_transfer_users2_idx` (`department`);

--
-- Indexes for table `transfer_request`
--
ALTER TABLE `transfer_request`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `uid` int(45) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `application_request`
--
ALTER TABLE `application_request`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `appliedpost`
--
ALTER TABLE `appliedpost`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `branch`
--
ALTER TABLE `branch`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `complain`
--
ALTER TABLE `complain`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `interview`
--
ALTER TABLE `interview`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `requrement`
--
ALTER TABLE `requrement`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transfer`
--
ALTER TABLE `transfer`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transfer_request`
--
ALTER TABLE `transfer_request`
  MODIFY `uid` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `application_request`
--
ALTER TABLE `application_request`
  ADD CONSTRAINT `fk_application_request_requrement1` FOREIGN KEY (`requrement`) REFERENCES `requrement` (`uid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_application_request_users` FOREIGN KEY (`employee`) REFERENCES `users` (`uid`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `complain`
--
ALTER TABLE `complain`
  ADD CONSTRAINT `fk_complain_users1` FOREIGN KEY (`employee`) REFERENCES `users` (`uid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_complain_users2` FOREIGN KEY (`department`) REFERENCES `users` (`uid`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `interview`
--
ALTER TABLE `interview`
  ADD CONSTRAINT `fk_interview_application_request1` FOREIGN KEY (`application_request_uid`) REFERENCES `application_request` (`uid`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `requrement`
--
ALTER TABLE `requrement`
  ADD CONSTRAINT `fk_requrement_city1` FOREIGN KEY (`city`) REFERENCES `city` (`uid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_requrement_users1` FOREIGN KEY (`department`) REFERENCES `users` (`uid`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `transfer`
--
ALTER TABLE `transfer`
  ADD CONSTRAINT `fk_transfer_interview1` FOREIGN KEY (`interview`) REFERENCES `interview` (`uid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_transfer_users1` FOREIGN KEY (`employee`) REFERENCES `users` (`uid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_transfer_users2` FOREIGN KEY (`department`) REFERENCES `users` (`uid`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
